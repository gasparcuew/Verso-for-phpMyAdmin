(() => {
  // Idempotente: el popup o el background pueden reinyectarlo en una pestaña ya abierta.
  if (globalThis.__pdmLoaded) return;
  globalThis.__pdmLoaded = true;

  const { DEFAULTS, DEFAULT_COLOR, DEFAULT_POSITION, matchSite, detectPmaVersion } = PDM;
  const root = document.documentElement;
  const CACHE_KEY = '__pdm_state';

  // Caché síncrona en el localStorage del sitio: evita el destello blanco mientras
  // storage.local (asíncrono) responde. Si no hay caché asumimos el theme por defecto.
  const readCache = () => {
    try {
      return JSON.parse(localStorage.getItem(CACHE_KEY));
    } catch {
      return null;
    }
  };
  const writeCache = (state) => {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(state));
    } catch {
      /* almacenamiento bloqueado */
    }
  };

  const whenBody = (fn) =>
    document.body ? fn() : document.addEventListener('DOMContentLoaded', fn, { once: true });

  /* ───────── Etiqueta del servidor ───────── */

  // Tres piezas, todas con el mismo nombre y color:
  //  · #pdm-env-line   línea de color de 3px (siempre)
  //  · #pdm-env        pastilla fija (centro y derecha)
  //  · #pdm-env-inline pastilla dentro del breadcrumb (izquierda)
  //
  // phpMyAdmin, en cada navegación AJAX:
  //  · ejecuta $('body').children().not(<lista blanca>).remove()
  //  · reemplaza todo el contenido de #floating_menubar
  let badge = null; // { name, color, position } vigente

  function ensure(id, tag, parent, first = false) {
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement(tag);
      el.id = id;
    }
    if (el.parentNode !== parent) first ? parent.prepend(el) : parent.append(el);
    return el;
  }

  function mountBadge() {
    const stale = (id) => document.getElementById(id)?.remove();
    if (!badge?.name) {
      ['pdm-env-line', 'pdm-env', 'pdm-env-inline'].forEach(stale);
      return;
    }

    const line = ensure('pdm-env-line', 'div', root);
    line.style.setProperty('--pdm-env', badge.color);

    const crumbs = badge.position === 'left' ? document.querySelector('#server-breadcrumb .breadcrumb') : null;
    let pill;
    if (crumbs) {
      stale('pdm-env');
      pill = ensure('pdm-env-inline', 'li', crumbs, true);
    } else {
      stale('pdm-env-inline');
      pill = ensure('pdm-env', 'div', root);
      pill.dataset.pos = badge.position; // sin breadcrumb (p. ej. login), "izquierda" cae aquí
    }
    pill.setAttribute('role', 'status');
    pill.textContent = badge.name; // textContent: el nombre nunca se interpreta como HTML
    pill.style.setProperty('--pdm-env', badge.color);
  }

  function renderBadge(next) {
    badge = next;
    whenBody(mountBadge);
  }

  // Restaurar si algo quita las piezas de <html>.
  new MutationObserver(() => {
    if (badge?.name && document.body && !document.getElementById('pdm-env-line')) mountBadge();
  }).observe(root, { childList: true });

  // Volver a insertar la pastilla del breadcrumb cuando phpMyAdmin repinta la barra.
  whenBody(() => {
    const bar = document.getElementById('floating_menubar');
    if (bar) new MutationObserver(() => badge?.name && mountBadge()).observe(bar, { childList: true });
  });

  /* ───────── Tinte total del entorno ───────── */

  function renderTint({ tintBorder, color }) {
    if (tintBorder && color) {
      root.setAttribute('data-pdm-tint', '');
      root.style.setProperty('--pdm-env', color);
    } else {
      root.removeAttribute('data-pdm-tint');
    }
  }

  /* ───────── Detección de versión de phpMyAdmin ───────── */

  function renderPmaVersion() {
    whenBody(() => {
      const ver = detectPmaVersion();
      root.setAttribute('data-pdm-pma', String(ver.major));
    });
  }

  /* ───────── Prefijo en el título de la pestaña ───────── */

  let wanted = ''; // prefijo deseado, p. ej. "[Supercluster] "
  let applied = ''; // prefijo que nosotros pusimos la última vez
  let watching = false;

  function syncTitle() {
    const title = document.title;
    const bare = applied && title.startsWith(applied) ? title.slice(applied.length) : title;
    if (wanted && !title.startsWith(wanted)) document.title = wanted + bare;
    else if (!wanted && applied && title.startsWith(applied)) document.title = bare;
    applied = wanted;
  }

  function watchTitle() {
    if (watching) return;
    const start = () => {
      watching = true;
      syncTitle();
      // phpMyAdmin cambia document.title tras cada navegación AJAX.
      new MutationObserver(syncTitle).observe(document.head, {
        subtree: true,
        childList: true,
        characterData: true,
      });
    };
    document.head ? start() : document.addEventListener('DOMContentLoaded', start, { once: true });
  }

  function renderTitle({ name, title }) {
    wanted = name && title ? `[${name}] ` : '';
    if (wanted || applied) watchTitle();
    if (watching) syncTitle();
  }

  /* ───────── Accesibilidad: font size y mono ───────── */

  function renderAccessibility({ fontSize, fontMono }) {
    if (fontSize && fontSize !== DEFAULTS.fontSize) {
      root.style.setProperty('--pdm-user-font-size', fontSize + 'px');
    } else {
      root.style.removeProperty('--pdm-user-font-size');
    }
    if (fontMono) {
      root.style.setProperty('--pdm-user-font-mono', fontMono);
    } else {
      root.style.removeProperty('--pdm-user-font-mono');
    }
  }

  /* ───────── Estado ───────── */

  function apply(state) {
    if (state.enabled) {
      root.dataset.pdm = state.theme;
      root.dataset.pdmDensity = state.density;
    } else {
      delete root.dataset.pdm;
      delete root.dataset.pdmDensity;
    }
    renderBadge({ name: state.name, color: state.color, position: state.position });
    renderTitle(state);
    renderTint({ tintBorder: state.tintBorder, color: state.color });
    renderAccessibility(state);
    renderPmaVersion();

    // Exponer estado para sql-guard.js y tables-pro.js
    globalThis.__pdmState = {
      name: state.name,
      color: state.color,
      critical: state.critical,
      tintBorder: state.tintBorder,
      enabled: state.enabled,
    };
  }

  async function load() {
    const { theme = DEFAULTS.theme, density = DEFAULTS.density, sites = {},
            fontSize = DEFAULTS.fontSize, fontMono = DEFAULTS.fontMono } =
      await chrome.storage.local.get(['theme', 'density', 'sites', 'fontSize', 'fontMono']);
    const site = matchSite(sites, location.href);
    const state = {
      theme,
      density,
      enabled: Boolean(site?.enabled),
      name: site?.name ?? '',
      color: site?.color ?? DEFAULT_COLOR,
      title: site?.title ?? true,
      position: site?.position ?? DEFAULT_POSITION,
      critical: site?.critical ?? false,
      tintBorder: site?.tintBorder ?? false,
      fontSize,
      fontMono,
    };
    writeCache(state);
    apply(state);
  }

  const cached = readCache();
  apply({
    ...{
      theme: DEFAULTS.theme, density: DEFAULTS.density, enabled: true,
      name: '', color: DEFAULT_COLOR, title: true, position: DEFAULT_POSITION,
      critical: false, tintBorder: false, fontSize: DEFAULTS.fontSize, fontMono: '',
    },
    ...cached,
  });
  load();

  chrome.storage.onChanged.addListener((_changes, area) => {
    if (area === 'local') load();
  });
})();
