/**
 * Protección SQL para servidores críticos.
 *
 * Cuando un servidor está marcado como "critical" en la configuración:
 *  · Intercepta formularios SQL antes de enviar
 *  · Detecta DROP, TRUNCATE, DELETE sin WHERE, UPDATE sin WHERE
 *  · Muestra un modal que pide escribir el nombre del servidor para confirmar
 *  · Muestra un toast sutil al ejecutar cualquier SQL
 *
 * Se carga después de boot.js; lee la configuración de __pdmState.
 */
(() => {
  if (globalThis.__pdmSqlGuard) return;
  globalThis.__pdmSqlGuard = true;

  const msg = (key, subs) => {
    try { return chrome.i18n?.getMessage(key, subs) || key; }
    catch { return key; }
  };

  /* ───────── Detección de queries peligrosas ───────── */

  /**
   * Analiza una consulta SQL y devuelve el tipo de operación peligrosa o null.
   * Elimina comentarios para evitar falsos negativos.
   */
  function detectDanger(sql) {
    // Quitar comentarios de bloque y de línea
    const clean = sql
      .replace(/\/\*[\s\S]*?\*\//g, ' ')
      .replace(/--.*$/gm, ' ')
      .replace(/#.*$/gm, ' ')
      .trim();

    // Dividir por ; para manejar múltiples statements
    const statements = clean.split(/;/).map(s => s.trim()).filter(Boolean);

    for (const stmt of statements) {
      const upper = stmt.toUpperCase();
      if (/^\s*DROP\b/.test(upper)) return 'DROP';
      if (/^\s*TRUNCATE\b/.test(upper)) return 'TRUNCATE';
      if (/^\s*DELETE\b/.test(upper) && !/\bWHERE\b/.test(upper)) {
        return msg('guardDeleteNoWhere');
      }
      if (/^\s*UPDATE\b/.test(upper) && !/\bWHERE\b/.test(upper)) {
        return msg('guardUpdateNoWhere');
      }
    }
    return null;
  }

  /* ───────── Extraer SQL del formulario ───────── */

  function extractSql() {
    // CodeMirror: el editor real de phpMyAdmin
    const cm = document.querySelector('.CodeMirror');
    if (cm?.CodeMirror) return cm.CodeMirror.getValue();

    // Textarea fallback (phpMyAdmin 4.x o sin CodeMirror)
    const ta = document.getElementById('sqlquery') ||
               document.getElementById('sql_query') ||
               document.querySelector('textarea[name="sql_query"]');
    if (ta) return ta.value;

    return '';
  }

  /* ───────── Modal de confirmación ───────── */

  function showConfirmModal(dangerType, serverName) {
    return new Promise((resolve) => {
      // Backdrop
      const backdrop = document.createElement('div');
      backdrop.id = 'pdm-guard-backdrop';
      Object.assign(backdrop.style, {
        position: 'fixed', inset: '0', zIndex: '2147483645',
        background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(3px)',
        display: 'grid', placeItems: 'center',
      });

      // Modal
      const modal = document.createElement('div');
      modal.id = 'pdm-guard-modal';
      Object.assign(modal.style, {
        width: '420px', maxWidth: '92vw',
        padding: '0', borderRadius: '14px', overflow: 'hidden',
        background: 'var(--pdm-surface, #151a21)',
        border: '1px solid var(--pdm-border, #2a323d)',
        boxShadow: '0 16px 48px rgba(0,0,0,0.6)',
        fontFamily: 'ui-sans-serif, system-ui, sans-serif',
        color: 'var(--pdm-text, #e4e9ef)',
      });

      // Header
      const header = document.createElement('div');
      Object.assign(header.style, {
        padding: '16px 20px', fontSize: '15px', fontWeight: '700',
        background: 'color-mix(in oklab, var(--pdm-danger, #ff6b6b) 14%, var(--pdm-surface, #151a21))',
        borderBottom: '1px solid var(--pdm-border, #2a323d)',
      });
      header.textContent = msg('guardTitle');

      // Body
      const body = document.createElement('div');
      Object.assign(body.style, { padding: '20px' });

      const msgEl = document.createElement('p');
      Object.assign(msgEl.style, { margin: '0 0 16px', lineHeight: '1.55', fontSize: '13.5px' });
      msgEl.innerHTML = `<span style="display:inline-block;padding:2px 8px;border-radius:6px;background:color-mix(in oklab,var(--pdm-danger,#ff6b6b) 18%,transparent);color:var(--pdm-danger,#ff6b6b);font-weight:700;font-size:12px;margin-right:6px">${escapeHtml(dangerType)}</span> ${escapeHtml(msg('guardMessage', [dangerType, serverName]))}`;

      const label = document.createElement('label');
      Object.assign(label.style, {
        display: 'block', fontSize: '12px', fontWeight: '600',
        color: 'var(--pdm-muted, #8a95a3)', marginBottom: '6px',
      });
      label.textContent = msg('guardConfirmLabel');

      const input = document.createElement('input');
      input.type = 'text';
      input.autocomplete = 'off';
      input.spellcheck = false;
      Object.assign(input.style, {
        width: '100%', padding: '8px 12px', fontSize: '14px',
        border: '1px solid var(--pdm-border, #2a323d)',
        borderRadius: '8px',
        background: 'var(--pdm-input, #0e1116)',
        color: 'var(--pdm-text, #e4e9ef)',
        outline: 'none', boxSizing: 'border-box',
      });
      input.addEventListener('focus', () => {
        input.style.borderColor = 'var(--pdm-accent, #4f9cff)';
        input.style.boxShadow = '0 0 0 3px var(--pdm-accent-soft, rgba(79,156,255,0.18))';
      });
      input.addEventListener('blur', () => {
        input.style.borderColor = 'var(--pdm-border, #2a323d)';
        input.style.boxShadow = 'none';
      });

      const error = document.createElement('p');
      Object.assign(error.style, {
        margin: '8px 0 0', fontSize: '12px', fontWeight: '600',
        color: 'var(--pdm-danger, #ff6b6b)', display: 'none',
      });
      error.textContent = msg('guardMismatch');

      body.append(msgEl, label, input, error);

      // Footer
      const footer = document.createElement('div');
      Object.assign(footer.style, {
        display: 'flex', justifyContent: 'flex-end', gap: '8px',
        padding: '12px 20px',
        borderTop: '1px solid var(--pdm-border, #2a323d)',
        background: 'var(--pdm-surface-2, #1d242d)',
      });

      const btnCancel = document.createElement('button');
      btnCancel.type = 'button';
      btnCancel.textContent = msg('guardCancel');
      Object.assign(btnCancel.style, {
        padding: '7px 16px', borderRadius: '8px', fontWeight: '600', fontSize: '13px',
        border: '1px solid var(--pdm-border, #2a323d)',
        background: 'var(--pdm-surface, #151a21)',
        color: 'var(--pdm-text, #e4e9ef)', cursor: 'pointer',
      });

      const btnConfirm = document.createElement('button');
      btnConfirm.type = 'button';
      btnConfirm.textContent = msg('guardConfirm');
      Object.assign(btnConfirm.style, {
        padding: '7px 16px', borderRadius: '8px', fontWeight: '700', fontSize: '13px',
        border: '1px solid transparent',
        background: 'var(--pdm-danger, #ff6b6b)',
        color: '#fff', cursor: 'pointer',
      });

      footer.append(btnCancel, btnConfirm);
      modal.append(header, body, footer);
      backdrop.append(modal);
      document.documentElement.append(backdrop);

      input.focus();

      function close(result) {
        backdrop.remove();
        resolve(result);
      }

      btnCancel.addEventListener('click', () => close(false));
      backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(false); });

      btnConfirm.addEventListener('click', () => {
        if (input.value.trim() === serverName) {
          close(true);
        } else {
          error.style.display = 'block';
          input.style.borderColor = 'var(--pdm-danger, #ff6b6b)';
          input.style.boxShadow = '0 0 0 3px color-mix(in oklab, var(--pdm-danger, #ff6b6b) 25%, transparent)';
          input.focus();
        }
      });

      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') btnConfirm.click();
        if (e.key === 'Escape') close(false);
      });
    });
  }

  /* ───────── Toast ───────── */

  function showToast(text, duration = 3000) {
    let toast = document.getElementById('pdm-guard-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'pdm-guard-toast';
      Object.assign(toast.style, {
        position: 'fixed', top: '8px', right: '16px', zIndex: '2147483646',
        padding: '8px 18px', borderRadius: '10px',
        background: 'color-mix(in oklab, var(--pdm-warning, #e3b341) 22%, var(--pdm-surface, #151a21))',
        color: 'var(--pdm-text, #e4e9ef)',
        border: '1px solid color-mix(in oklab, var(--pdm-warning, #e3b341) 45%, transparent)',
        font: '600 12px/1.4 ui-sans-serif, system-ui, sans-serif',
        boxShadow: '0 6px 24px rgba(0,0,0,0.5)',
        pointerEvents: 'none', opacity: '0',
        transition: 'opacity 0.25s',
      });
      document.documentElement.append(toast);
    }
    toast.textContent = text;
    toast.style.opacity = '1';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, duration);
  }

  function escapeHtml(str) {
    const d = document.createElement('div');
    d.textContent = str;
    return d.innerHTML;
  }

  /* ───────── Interceptar forms ───────── */

  /**
   * Busca todos los formularios de SQL e instala el guard.
   * phpMyAdmin puede recrear el form en navegaciones AJAX,
   * así que se reinspecciona cada vez.
   */
  function installGuard(serverName) {
    const forms = document.querySelectorAll(
      '#sqlform, form[name="sqlform"], form[action*="sql.php"], ' +
      'form[action*="import.php"], form[action*="tbl_sql.php"], ' +
      'form[action*="db_sql.php"], form[action*="server_sql.php"], ' +
      '#query_form'
    );

    for (const form of forms) {
      if (form._pdmGuarded) continue;
      form._pdmGuarded = true;

      form.addEventListener('submit', async function handler(e) {
        const sql = extractSql();
        if (!sql.trim()) return;

        const danger = detectDanger(sql);
        if (danger) {
          e.preventDefault();
          e.stopImmediatePropagation();

          const confirmed = await showConfirmModal(danger, serverName);
          if (confirmed) {
            // Quitar el handler temporal para que no se cicle
            form.removeEventListener('submit', handler);
            form._pdmGuarded = false;
            form.requestSubmit();
          }
          return;
        }

        // No es peligroso, pero avisar que se está ejecutando SQL en servidor crítico
        showToast(`⚡ ${msg('guardToast')}: ${serverName}`);
      }, { capture: true });
    }
  }

  /* ───────── Init: esperar a que boot.js establezca el estado ───────── */

  function init() {
    // __pdmState lo pone boot.js con la info del servidor actual
    const poll = () => {
      const state = globalThis.__pdmState;
      if (!state) return setTimeout(poll, 200);

      if (!state.critical || !state.name) return; // no es crítico o no tiene nombre

      installGuard(state.name);

      // Reinstalar tras navegaciones AJAX de phpMyAdmin
      const observer = new MutationObserver(() => {
        installGuard(state.name);
      });

      const content = document.getElementById('page_content') || document.body;
      observer.observe(content, { childList: true, subtree: true });
    };
    poll();
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init, { once: true });
})();
