/**
 * Tablas "pro" para Verso for phpMyAdmin.
 *
 * Mejoras sobre las tablas de resultados de phpMyAdmin:
 *  · Cabecera fija al hacer scroll (clase .pdm-scrolled)
 *  · Clic para copiar una celda
 *  · JSON formateado y colapsable en celdas
 *  · URLs clicables
 *  · Fechas legibles con tooltip relativo
 *  · Columnas redimensionables con drag
 *  · Columnas ocultables (clic derecho en cabecera)
 *
 * Se ejecuta después de boot.js. No depende de que el modo oscuro
 * esté activo: funciona mientras la extensión esté habilitada.
 */
(() => {
  if (globalThis.__pdmTablesPro) return;
  globalThis.__pdmTablesPro = true;

  const msg = (key, subs) => {
    try { return chrome.i18n?.getMessage(key, subs) || key; }
    catch { return key; }
  };

  const STORAGE_PREFIX = 'pdm_tbl_';

  /* ───────── Utilidades ───────── */

  /** Nombre de tabla actual para persistir configuración por tabla. */
  function getTableId() {
    // Intentar extraer del breadcrumb
    const bc = document.querySelector('#server-breadcrumb .breadcrumb');
    if (bc) {
      const items = bc.querySelectorAll('.breadcrumb-item');
      const parts = Array.from(items).map(i => i.textContent.trim()).filter(Boolean);
      return parts.join('/');
    }
    // Fallback: usar la URL
    return location.pathname + location.search;
  }

  function saveTablePref(tableId, key, value) {
    try { localStorage.setItem(STORAGE_PREFIX + tableId + '_' + key, JSON.stringify(value)); }
    catch { /* quota */ }
  }

  function loadTablePref(tableId, key) {
    try { return JSON.parse(localStorage.getItem(STORAGE_PREFIX + tableId + '_' + key)); }
    catch { return null; }
  }

  /* ───────── Toast ───────── */

  function showToast(text, duration = 1800) {
    let toast = document.getElementById('pdm-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'pdm-toast';
      document.documentElement.append(toast);
    }
    toast.textContent = text;
    toast.classList.add('pdm-show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('pdm-show'), duration);
  }

  /* ───────── 1. Cabecera fija al scroll ───────── */

  function initStickyHeaders(table) {
    // Detectar el contenedor scrollable
    const container = table.closest('.table-responsive, .responsivetable') ||
      table.closest('#page_content') ||
      table.parentElement;
    if (!container) return;

    const check = () => {
      const rect = table.getBoundingClientRect();
      const containerRect = container.getBoundingClientRect();
      const scrolled = rect.top < containerRect.top - 1;
      table.classList.toggle('pdm-scrolled', scrolled);
    };

    // Si el container scrollea, observar su scroll; si no, observar window
    if (container.scrollHeight > container.clientHeight) {
      container.addEventListener('scroll', check, { passive: true });
    }
    window.addEventListener('scroll', check, { passive: true });
    check();
  }

  /* ───────── 2. Clic para copiar ───────── */

  function initCopyOnClick(table) {
    // Marcar celdas de datos (no celdas de acciones con links/botones)
    table.querySelectorAll('tbody td').forEach(td => {
      if (td.querySelector('a, button, input, select, textarea')) return;
      td.setAttribute('data-pdm-copy', '');
    });

    table.addEventListener('click', async (e) => {
      const td = e.target.closest('td[data-pdm-copy]');
      if (!td) return;
      if (e.target.closest('a, button, details, input')) return;

      const text = td.textContent.trim();
      if (!text) return;

      try {
        await navigator.clipboard.writeText(text);
        showToast(msg('tableCopied'));
      } catch {
        // Fallback para contextos sin permiso de clipboard
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.cssText = 'position:fixed;opacity:0;';
        document.body.append(ta);
        ta.select();
        document.execCommand('copy');
        ta.remove();
        showToast(msg('tableCopied'));
      }
    });
  }

  /* ───────── 3. JSON formateado y colapsable ───────── */

  function isJsonLike(text) {
    const t = text.trim();
    return (t.startsWith('{') && t.endsWith('}')) || (t.startsWith('[') && t.endsWith(']'));
  }

  function highlightJson(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"([^"\\]*(\\.[^"\\]*)*)"\s*:/g,
        '<span class="pdm-json-key">"$1"</span>:')
      .replace(/:\s*"([^"\\]*(\\.[^"\\]*)*)"/g,
        ': <span class="pdm-json-string">"$1"</span>')
      .replace(/:\s*(\d+\.?\d*)/g,
        ': <span class="pdm-json-number">$1</span>')
      .replace(/:\s*(true|false)/g,
        ': <span class="pdm-json-bool">$1</span>')
      .replace(/:\s*(null)/g,
        ': <span class="pdm-json-null">$1</span>');
  }

  function initJsonCells(table) {
    table.querySelectorAll('tbody td').forEach(td => {
      if (td.querySelector('details, a, button, input')) return;
      const raw = td.textContent.trim();
      if (!isJsonLike(raw)) return;

      let parsed;
      try { parsed = JSON.parse(raw); } catch { return; }

      const summary = Array.isArray(parsed)
        ? `Array[${parsed.length}]`
        : `Object{${Object.keys(parsed).length}}`;

      const formatted = JSON.stringify(parsed, null, 2);

      const details = document.createElement('details');
      details.className = 'pdm-json';

      const sumEl = document.createElement('summary');
      sumEl.textContent = summary;

      const pre = document.createElement('pre');
      pre.innerHTML = highlightJson(formatted);

      details.append(sumEl, pre);
      td.textContent = '';
      td.append(details);
      td.removeAttribute('data-pdm-copy'); // JSON cells get their own copy
    });
  }

  /* ───────── 4. URLs clicables ───────── */

  const URL_RE = /https?:\/\/[^\s<>"'`,;)}\]]+/g;

  function initClickableUrls(table) {
    table.querySelectorAll('tbody td').forEach(td => {
      if (td.querySelector('a, details, button, input')) return;
      const text = td.textContent;
      if (!URL_RE.test(text)) return;
      URL_RE.lastIndex = 0;

      // Usar un fragment para no perder contenido
      const frag = document.createDocumentFragment();
      let last = 0;
      let match;
      URL_RE.lastIndex = 0;
      while ((match = URL_RE.exec(text)) !== null) {
        if (match.index > last) {
          frag.append(document.createTextNode(text.slice(last, match.index)));
        }
        const a = document.createElement('a');
        a.href = match[0];
        a.textContent = match[0];
        a.target = '_blank';
        a.rel = 'noopener noreferrer';
        a.className = 'pdm-url';
        frag.append(a);
        last = match.index + match[0].length;
      }
      if (last < text.length) {
        frag.append(document.createTextNode(text.slice(last)));
      }

      td.textContent = '';
      td.append(frag);
    });
  }

  /* ───────── 5. Fechas legibles ───────── */

  const ISO_RE = /^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}/;
  const UNIX_RE = /^\d{10}$/;
  const UNIX_MS_RE = /^\d{13}$/;

  function relativeTime(date) {
    const now = Date.now();
    const diff = now - date.getTime();
    const abs = Math.abs(diff);
    const sign = diff >= 0 ? 'ago' : 'in';

    if (abs < 60000) return `just now`;
    if (abs < 3600000) return `${Math.floor(abs / 60000)}m ${sign}`;
    if (abs < 86400000) return `${Math.floor(abs / 3600000)}h ${sign}`;
    if (abs < 2592000000) return `${Math.floor(abs / 86400000)}d ${sign}`;
    if (abs < 31536000000) return `${Math.floor(abs / 2592000000)}mo ${sign}`;
    return `${Math.floor(abs / 31536000000)}y ${sign}`;
  }

  function initReadableDates(table) {
    table.querySelectorAll('tbody td').forEach(td => {
      if (td.querySelector('a, details, .pdm-date')) return;
      const text = td.textContent.trim();
      let date;

      if (ISO_RE.test(text)) {
        date = new Date(text.replace(' ', 'T'));
      } else if (UNIX_RE.test(text)) {
        date = new Date(parseInt(text) * 1000);
      } else if (UNIX_MS_RE.test(text)) {
        date = new Date(parseInt(text));
      }

      if (!date || isNaN(date.getTime())) return;

      // Solo marcar si la fecha es razonable (1990-2100)
      const year = date.getFullYear();
      if (year < 1990 || year > 2100) return;

      td.classList.add('pdm-date');

      // Tooltip con fecha legible y relativa
      const locale = navigator.language || 'en';
      const formatted = date.toLocaleString(locale, {
        weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
      });
      td.title = `${formatted}\n${relativeTime(date)}`;

      // Mostrar la fecha relativa debajo si es un timestamp Unix
      if (UNIX_RE.test(text) || UNIX_MS_RE.test(text)) {
        const rel = document.createElement('small');
        rel.className = 'pdm-date-relative';
        rel.textContent = relativeTime(date);
        td.append(rel);
      }
    });
  }

  /* ───────── 6. Columnas redimensionables ───────── */

  function initResizableColumns(table) {
    const tableId = getTableId();
    const savedWidths = loadTablePref(tableId, 'widths') || {};

    table.querySelectorAll('thead th').forEach((th, idx) => {
      // Aplicar anchos guardados
      if (savedWidths[idx]) {
        th.style.width = savedWidths[idx] + 'px';
        th.style.minWidth = savedWidths[idx] + 'px';
      }

      th.style.position = 'relative';

      const handle = document.createElement('div');
      handle.className = 'pdm-resize-handle';
      th.append(handle);

      let startX, startWidth;

      handle.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        startX = e.clientX;
        startWidth = th.offsetWidth;
        handle.classList.add('pdm-resizing');
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';

        const move = (ev) => {
          const newWidth = Math.max(40, startWidth + ev.clientX - startX);
          th.style.width = newWidth + 'px';
          th.style.minWidth = newWidth + 'px';
        };

        const up = () => {
          document.removeEventListener('mousemove', move);
          document.removeEventListener('mouseup', up);
          handle.classList.remove('pdm-resizing');
          document.body.style.cursor = '';
          document.body.style.userSelect = '';

          // Guardar anchos
          const widths = {};
          table.querySelectorAll('thead th').forEach((t, i) => {
            if (t.style.width) widths[i] = parseInt(t.style.width);
          });
          saveTablePref(tableId, 'widths', widths);
        };

        document.addEventListener('mousemove', move);
        document.addEventListener('mouseup', up);
      });
    });
  }

  /* ───────── 7. Columnas ocultables ───────── */

  function initHideableColumns(table) {
    const tableId = getTableId();
    const hiddenCols = new Set(loadTablePref(tableId, 'hidden') || []);

    // Aplicar columnas ocultas guardadas
    function applyHidden() {
      const ths = table.querySelectorAll('thead th');
      ths.forEach((th, idx) => {
        const cells = table.querySelectorAll(`tr > :nth-child(${idx + 1})`);
        cells.forEach(cell => {
          cell.classList.toggle('pdm-col-hidden', hiddenCols.has(idx));
        });
      });
      updateHiddenBar();
    }

    // Barra de info sobre columnas ocultas
    function updateHiddenBar() {
      let bar = document.getElementById('pdm-col-bar');
      if (hiddenCols.size === 0) {
        bar?.remove();
        return;
      }
      if (!bar) {
        bar = document.createElement('div');
        bar.id = 'pdm-col-bar';
        table.parentElement.insertBefore(bar, table);
      }
      bar.innerHTML = '';
      const info = document.createElement('span');
      info.textContent = msg('tableColsHidden', [String(hiddenCols.size)]);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = msg('tableShowAll');
      btn.addEventListener('click', () => {
        hiddenCols.clear();
        saveTablePref(tableId, 'hidden', []);
        applyHidden();
      });
      bar.append(info, btn);
    }

    // Menú contextual
    table.querySelectorAll('thead th').forEach((th, idx) => {
      th.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showColumnMenu(e.clientX, e.clientY, th, idx);
      });
    });

    function showColumnMenu(x, y, th, idx) {
      // Quitar menú anterior
      document.getElementById('pdm-col-menu')?.remove();

      const menu = document.createElement('div');
      menu.id = 'pdm-col-menu';
      menu.style.left = x + 'px';
      menu.style.top = y + 'px';

      // Ocultar esta columna
      const hideBtn = document.createElement('button');
      hideBtn.type = 'button';
      const colName = th.textContent.trim() || `#${idx + 1}`;
      hideBtn.textContent = msg('tableHideColumn', [colName]);
      hideBtn.addEventListener('click', () => {
        hiddenCols.add(idx);
        saveTablePref(tableId, 'hidden', [...hiddenCols]);
        applyHidden();
        menu.remove();
      });
      menu.append(hideBtn);

      // Si hay columnas ocultas, opción de mostrar todas
      if (hiddenCols.size > 0) {
        const hr = document.createElement('hr');
        const showBtn = document.createElement('button');
        showBtn.type = 'button';
        showBtn.textContent = msg('tableShowAll');
        showBtn.addEventListener('click', () => {
          hiddenCols.clear();
          saveTablePref(tableId, 'hidden', []);
          applyHidden();
          menu.remove();
        });
        menu.append(hr, showBtn);
      }

      document.documentElement.append(menu);

      // Ajustar posición si se sale de la pantalla
      const rect = menu.getBoundingClientRect();
      if (rect.right > window.innerWidth) menu.style.left = (window.innerWidth - rect.width - 8) + 'px';
      if (rect.bottom > window.innerHeight) menu.style.top = (window.innerHeight - rect.height - 8) + 'px';

      // Cerrar al hacer clic fuera
      const close = (ev) => {
        if (!menu.contains(ev.target)) {
          menu.remove();
          document.removeEventListener('click', close, true);
        }
      };
      setTimeout(() => document.addEventListener('click', close, true), 0);
    }

    applyHidden();
  }

  /* ───────── Init: procesar tablas de resultados ───────── */

  function processTable(table) {
    if (table._pdmPro) return;
    table._pdmPro = true;

    // Orden importa: JSON antes de URLs (JSON puede contener URLs)
    initStickyHeaders(table);
    initJsonCells(table);
    initClickableUrls(table);
    initReadableDates(table);
    initCopyOnClick(table);
    initResizableColumns(table);
    initHideableColumns(table);
  }

  function findAndProcessTables() {
    document.querySelectorAll('.table_results, table.data').forEach(processTable);
  }

  function init() {
    findAndProcessTables();

    // phpMyAdmin recarga tablas vía AJAX
    const content = document.getElementById('page_content') || document.body;
    new MutationObserver(() => {
      findAndProcessTables();
    }).observe(content, { childList: true, subtree: true });
  }

  if (document.body) init();
  else document.addEventListener('DOMContentLoaded', init, { once: true });
})();
