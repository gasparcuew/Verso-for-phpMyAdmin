const {
  THEMES,
  COLORS,
  POSITIONS,
  DEFAULTS,
  DEFAULT_SERVERS,
  normalizeSavedServers,
  normalizeSite,
  toOrigin,
  msg,
} = PDM;

const $ = (s) => document.querySelector(s);
const root = document.documentElement;

let currentSettings = { ...DEFAULTS, sites: {}, savedServers: DEFAULT_SERVERS };

/* ──────── Toast ──────── */
let toastTimeout;
function showToast(text) {
  const el = $('#optToast');
  if (!el) return;
  el.textContent = text;
  el.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => el.classList.remove('show'), 2400);
}

/* ──────── i18n ──────── */
function applyI18n() {
  const set = (id, key) => {
    const el = $(id);
    if (el) el.textContent = msg(key);
  };
  set('#optPageTitle', 'extName');
  set('#secAppearance', 'optAppearance');
  set('#labelTheme', 'popupTheme');
  set('#labelDensity', 'popupDensity');
  set('#optComfortable', 'popupDensityComfortable');
  set('#optCompact', 'popupDensityCompact');

  set('#secAccessibility', 'optAccessibility');
  set('#labelFontSize', 'optFontSize');
  set('#labelFontMono', 'optFontMono');
  set('#monoDefault', 'optFontMonoDefault');
  set('#labelContrastAA', 'optContrastAA');

  set('#secServers', 'optServers');
  set('#secSync', 'optSync');
  set('#labelSync', 'optSyncEnabled');
  set('#labelBackup', 'optExportImport');
  set('#btnExportText', 'optExport');
  set('#btnImportText', 'optImport');
  set('#btnResetText', 'optReset');
}

/* ──────── Carga y guardado ──────── */
async function loadSettings() {
  const data = await chrome.storage.local.get([
    'theme',
    'density',
    'fontSize',
    'fontMono',
    'contrastAA',
    'syncEnabled',
    'sites',
    'savedServers',
  ]);
  currentSettings = {
    theme: data.theme ?? DEFAULTS.theme,
    density: data.density ?? DEFAULTS.density,
    fontSize: data.fontSize ?? DEFAULTS.fontSize,
    fontMono: data.fontMono ?? DEFAULTS.fontMono,
    contrastAA: Boolean(data.contrastAA),
    syncEnabled: Boolean(data.syncEnabled),
    sites: data.sites ?? {},
    savedServers: normalizeSavedServers(data.savedServers),
  };
}

async function saveSetting(key, value) {
  currentSettings[key] = value;
  await chrome.storage.local.set({ [key]: value });
  showToast(msg('tableCopied') ? 'Guardado' : 'Saved');
}

/* ──────── Renderers ──────── */
function renderThemes() {
  const grid = $('#themesGrid');
  grid.replaceChildren();

  for (const { id, name } of THEMES) {
    const label = document.createElement('label');
    label.className = 'theme-card';
    label.innerHTML = `
      <input type="radio" name="optTheme" value="${id}" ${currentSettings.theme === id ? 'checked' : ''} />
      <div class="theme-preview" data-pdm="${id}">
        <div class="mock-sidebar"></div>
        <div class="mock-header"></div>
        <div class="mock-body"><i></i><i></i><i></i></div>
      </div>
      <span class="theme-name">${name}</span>
    `;
    label.querySelector('input').addEventListener('change', async (e) => {
      root.dataset.pdm = e.target.value;
      await saveSetting('theme', e.target.value);
    });
    grid.append(label);
  }
}

function renderDensity() {
  const group = $('#densityGroup');
  const match = group.querySelector(`input[value="${currentSettings.density}"]`);
  if (match) match.checked = true;

  group.querySelectorAll('input').forEach((input) => {
    input.addEventListener('change', async (e) => {
      await saveSetting('density', e.target.value);
    });
  });
}

function renderAccessibility() {
  const range = $('#fontSizeRange');
  const val = $('#fontSizeVal');
  range.value = currentSettings.fontSize;
  val.textContent = `${currentSettings.fontSize}px`;

  range.addEventListener('input', (e) => {
    val.textContent = `${e.target.value}px`;
  });
  range.addEventListener('change', async (e) => {
    await saveSetting('fontSize', parseInt(e.target.value, 10));
  });

  const mono = $('#fontMonoSelect');
  mono.value = currentSettings.fontMono;
  mono.addEventListener('change', async (e) => {
    await saveSetting('fontMono', e.target.value);
  });

  const aa = $('#contrastAA');
  aa.checked = currentSettings.contrastAA;
  aa.addEventListener('change', async (e) => {
    await saveSetting('contrastAA', e.target.checked);
  });
}

function renderSavedServers() {
  const container = $('#savedServersList');
  if (!container) return;
  container.replaceChildren();

  const servers = currentSettings.savedServers;
  if (!servers.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = 'No hay servidores registrados aún.';
    container.append(empty);
    return;
  }

  for (let i = 0; i < servers.length; i++) {
    const s = servers[i];
    const item = document.createElement('div');
    item.className = `server-item ${s.critical ? 'critical-server' : ''}`;

    item.innerHTML = `
      <div class="server-info">
        <div class="server-host">
          <span class="server-pill" style="--pill-color:${s.color}">${s.name}</span>
          ${s.isPreset ? '<small style="opacity:0.6;font-size:11px;">(Preset)</small>' : ''}
        </div>
        <div class="server-meta-row">
          <label class="inline-checkbox">
            <input type="checkbox" class="chk-critical" ${s.critical ? 'checked' : ''} />
            <span>${msg('popupCritical')}</span>
          </label>
          <label class="inline-checkbox">
            <input type="checkbox" class="chk-tint" ${s.tintBorder ? 'checked' : ''} />
            <span>${msg('popupTintBorder')}</span>
          </label>
        </div>
      </div>
      <div class="server-actions">
        ${
          !s.isPreset
            ? `<button type="button" class="btn-icon btn-remove" title="${msg('popupRemove')}" aria-label="${msg('popupRemove')}">
                 <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
               </button>`
            : ''
        }
      </div>
    `;

    item.querySelector('.chk-critical').addEventListener('change', async (e) => {
      s.critical = e.target.checked;
      await saveSetting('savedServers', currentSettings.savedServers);
      item.classList.toggle('critical-server', s.critical);
    });

    item.querySelector('.chk-tint').addEventListener('change', async (e) => {
      s.tintBorder = e.target.checked;
      await saveSetting('savedServers', currentSettings.savedServers);
    });

    const rmBtn = item.querySelector('.btn-remove');
    if (rmBtn) {
      rmBtn.addEventListener('click', async () => {
        currentSettings.savedServers.splice(i, 1);
        await saveSetting('savedServers', currentSettings.savedServers);
        renderSavedServers();
        showToast('Servidor eliminado de la biblioteca');
      });
    }

    container.append(item);
  }
}

function setupAddServer() {
  const btn = $('#btnAddServer');
  if (!btn) return;

  btn.addEventListener('click', async () => {
    const nameInput = $('#newServerName');
    const colorSelect = $('#newServerColor');
    const criticalCheck = $('#newServerCritical');
    const tintCheck = $('#newServerTint');

    const name = (nameInput.value || '').trim();
    if (!name) {
      nameInput.focus();
      return;
    }

    const idx = currentSettings.savedServers.findIndex((s) => s.name.toLowerCase() === name.toLowerCase());
    const newServer = {
      name,
      color: colorSelect.value,
      critical: criticalCheck.checked,
      tintBorder: tintCheck.checked,
      position: PDM.DEFAULT_POSITION,
      isPreset: false,
    };

    if (idx >= 0) {
      currentSettings.savedServers[idx] = newServer;
    } else {
      currentSettings.savedServers.push(newServer);
    }

    await saveSetting('savedServers', currentSettings.savedServers);
    nameInput.value = '';
    criticalCheck.checked = false;
    tintCheck.checked = false;
    renderSavedServers();
    showToast('Servidor guardado');
  });
}

function renderServers() {
  const container = $('#serversList');
  container.replaceChildren();

  const keys = Object.keys(currentSettings.sites);
  if (!keys.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.textContent = msg('popupNoServers');
    container.append(empty);
    return;
  }

  for (const key of keys) {
    const site = normalizeSite(currentSettings.sites[key]);
    const item = document.createElement('div');
    item.className = `server-item ${site.critical ? 'critical-server' : ''}`;

    const host = key.replace(/^https?:\/\//, '');

    item.innerHTML = `
      <div class="server-info">
        <div class="server-host">
          <code>${host}</code>
          ${site.name ? `<span class="server-pill" style="--pill-color:${site.color}">${site.name}</span>` : ''}
        </div>
        <div class="server-meta-row">
          <label class="inline-checkbox">
            <input type="checkbox" class="chk-critical" ${site.critical ? 'checked' : ''} />
            <span>${msg('popupCritical')}</span>
          </label>
          <label class="inline-checkbox">
            <input type="checkbox" class="chk-tint" ${site.tintBorder ? 'checked' : ''} />
            <span>${msg('popupTintBorder')}</span>
          </label>
        </div>
      </div>
      <div class="server-actions">
        <button type="button" class="btn-icon btn-remove" title="${msg('popupRemove')}" aria-label="${msg('popupRemove')}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
        </button>
      </div>
    `;

    item.querySelector('.chk-critical').addEventListener('change', async (e) => {
      site.critical = e.target.checked;
      currentSettings.sites[key] = site;
      await chrome.storage.local.set({ sites: currentSettings.sites });
      item.classList.toggle('critical-server', site.critical);
      showToast('Guardado');
    });

    item.querySelector('.chk-tint').addEventListener('change', async (e) => {
      site.tintBorder = e.target.checked;
      currentSettings.sites[key] = site;
      await chrome.storage.local.set({ sites: currentSettings.sites });
      showToast('Guardado');
    });

    item.querySelector('.btn-remove').addEventListener('click', async () => {
      delete currentSettings.sites[key];
      await chrome.storage.local.set({ sites: currentSettings.sites });
      const origin = toOrigin(key);
      if (!Object.keys(currentSettings.sites).some((k) => toOrigin(k) === origin)) {
        await chrome.permissions.remove({ origins: [origin] });
      }
      renderServers();
      showToast('Eliminado');
    });

    container.append(item);
  }
}

function renderSync() {
  const sync = $('#syncEnabled');
  sync.checked = currentSettings.syncEnabled;
  sync.addEventListener('change', async (e) => {
    await saveSetting('syncEnabled', e.target.checked);
  });
}

function setupBackup() {
  // Exportar
  $('#btnExport').addEventListener('click', () => {
    const backup = {
      app: 'phpmyadmin-dark',
      version: 2,
      exportedAt: new Date().toISOString(),
      ...currentSettings,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `phpmyadmin-dark-config-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(msg('optExport'));
  });

  // Importar
  $('#fileImport').addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const imported = JSON.parse(event.target.result);
        if (!imported || typeof imported !== 'object') throw new Error('Formato inválido');

        const patch = {};
        if (imported.theme && THEMES.some((t) => t.id === imported.theme)) patch.theme = imported.theme;
        if (imported.density) patch.density = imported.density;
        if (typeof imported.fontSize === 'number') patch.fontSize = imported.fontSize;
        if (typeof imported.fontMono === 'string') patch.fontMono = imported.fontMono;
        if (typeof imported.contrastAA === 'boolean') patch.contrastAA = imported.contrastAA;
        if (typeof imported.syncEnabled === 'boolean') patch.syncEnabled = imported.syncEnabled;
        if (imported.sites && typeof imported.sites === 'object') patch.sites = imported.sites;
        if (Array.isArray(imported.savedServers)) patch.savedServers = normalizeSavedServers(imported.savedServers);

        await chrome.storage.local.set(patch);
        await loadSettings();
        root.dataset.pdm = currentSettings.theme;
        renderThemes();
        renderDensity();
        renderAccessibility();
        renderSavedServers();
        renderServers();
        renderSync();
        showToast(msg('optImportSuccess'));
      } catch (err) {
        showToast(msg('optImportError'));
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // permitir re-selección
  });

  // Restablecer
  $('#btnReset').addEventListener('click', async () => {
    if (!confirm(msg('optResetConfirm'))) return;
    await chrome.storage.local.clear();
    await chrome.storage.local.set({
      theme: DEFAULTS.theme,
      density: DEFAULTS.density,
      fontSize: DEFAULTS.fontSize,
      fontMono: DEFAULTS.fontMono,
      contrastAA: DEFAULTS.contrastAA,
      syncEnabled: DEFAULTS.syncEnabled,
      sites: {},
      savedServers: DEFAULT_SERVERS,
    });
    await loadSettings();
    root.dataset.pdm = currentSettings.theme;
    renderThemes();
    renderDensity();
    renderAccessibility();
    renderSavedServers();
    renderServers();
    renderSync();
    showToast(msg('optReset'));
  });
}

/* ──────── Init ──────── */
(async () => {
  applyI18n();
  $('#optVersion').textContent = `v${chrome.runtime.getManifest().version}`;
  await loadSettings();
  root.dataset.pdm = currentSettings.theme;
  renderThemes();
  renderDensity();
  renderAccessibility();
  renderSavedServers();
  setupAddServer();
  renderServers();
  renderSync();
  setupBackup();
})();
