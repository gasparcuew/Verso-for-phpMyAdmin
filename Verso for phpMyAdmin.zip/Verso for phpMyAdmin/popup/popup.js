const {
  THEMES,
  COLORS,
  POSITIONS,
  DEFAULTS,
  NAME_MAX,
  PMA_SELECTOR,
  DEFAULT_SERVERS,
  normalizeSavedServers,
  normalizeSite,
  siteKey,
  matchSite,
  toOrigin,
  msg,
} = PDM;

const $ = (selector) => document.querySelector(selector);
const root = document.documentElement;

const storage = {
  async read() {
    const {
      theme = DEFAULTS.theme,
      density = DEFAULTS.density,
      sites = {},
      savedServers = DEFAULTS.savedServers,
    } = await chrome.storage.local.get(['theme', 'density', 'sites', 'savedServers']);
    return {
      theme,
      density,
      sites,
      savedServers: normalizeSavedServers(savedServers),
    };
  },
  write: (patch) => chrome.storage.local.set(patch),
};

let tab = null; // pestaña activa
let page = null; // { url, key, isPma } | null si no es inspeccionable

/** Con activeTab podemos inspeccionar la pestaña sin permisos de host amplios. */
async function inspect() {
  [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url || !/^https?:/.test(tab.url)) return null;
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (selector) => Boolean(document.querySelector(selector)),
      args: [PMA_SELECTOR],
    });
    return { url: tab.url, key: siteKey(tab.url), isPma: result };
  } catch {
    return null;
  }
}

/** Elimina sitios cuyo permiso nunca se concedió. */
async function pruneSites() {
  const { sites } = await storage.read();
  let changed = false;
  for (const key of Object.keys(sites)) {
    if (!(await chrome.permissions.contains({ origins: [toOrigin(key)] }))) {
      delete sites[key];
      changed = true;
    }
  }
  if (changed) await storage.write({ sites });
}

/* ───────── Gestión de Servidores Registrados ───────── */

/** Guarda o actualiza un servidor en la biblioteca EXCLUSIVAMENTE cuando el usuario lo solicita. */
async function persistServer(profile) {
  const name = String(profile?.name || '').trim().slice(0, NAME_MAX);
  if (!name) return;

  const { savedServers } = await storage.read();
  const idx = savedServers.findIndex((s) => s.name.toLowerCase() === name.toLowerCase());

  const serverObj = {
    name,
    color: profile.color || PDM.DEFAULT_COLOR,
    critical: profile.critical === true,
    tintBorder: profile.tintBorder === true,
    position: profile.position || PDM.DEFAULT_POSITION,
    isPreset: idx >= 0 ? savedServers[idx].isPreset : false,
  };

  if (idx >= 0) {
    savedServers[idx] = { ...savedServers[idx], ...serverObj };
  } else {
    savedServers.push(serverObj);
  }

  await storage.write({ savedServers });
}

/** Elimina un servidor de la biblioteca de guardados. */
async function deleteSavedServer(serverName) {
  const { savedServers } = await storage.read();
  const filtered = savedServers.filter(
    (s) => s.name.toLowerCase() !== serverName.toLowerCase() || s.isPreset
  );
  await storage.write({ savedServers: filtered });
}

/* ───────── Acciones ───────── */

async function activate() {
  const key = page.key;
  const { sites } = await storage.read();

  sites[key] = normalizeSite({ enabled: true });
  await storage.write({ sites });

  const granted = await chrome.permissions.request({ origins: [toOrigin(key)] });
  if (!granted) {
    delete sites[key];
    await storage.write({ sites });
  }
  await render();
  if (granted) $('#serverName').focus();
}

/** Actualiza el sitio actual. NO crea servidores nuevos en la biblioteca automáticamente. */
async function updateSite(key, patch) {
  const { sites, savedServers } = await storage.read();
  if (!sites[key]) return;
  const updated = { ...normalizeSite(sites[key]), ...patch };
  sites[key] = updated;
  await storage.write({ sites });

  // Si el nombre ya existe en la biblioteca, actualiza sus propiedades si cambiaron
  if (updated.name) {
    const existing = savedServers.find((s) => s.name.toLowerCase() === updated.name.toLowerCase());
    if (existing) {
      existing.color = updated.color;
      existing.critical = updated.critical;
      existing.tintBorder = updated.tintBorder;
      existing.position = updated.position;
      await storage.write({ savedServers });
    }
  }
}

async function removeSite(key) {
  const { sites } = await storage.read();
  delete sites[key];
  await storage.write({ sites });

  const origin = toOrigin(key);
  if (!Object.keys(sites).some((k) => toOrigin(k) === origin)) {
    await chrome.permissions.remove({ origins: [origin] });
  }
  await render();
}

const debounce = (fn, ms) => {
  let id;
  return (...args) => {
    clearTimeout(id);
    id = setTimeout(() => fn(...args), ms);
  };
};

/* ───────── Render ───────── */

function paintPill(el, { name, color }) {
  el.textContent = name;
  el.style.setProperty('--c', color);
}

function renderThemes(current) {
  const box = $('#themes');
  if (!box.querySelector('.theme')) {
    for (const { id, name } of THEMES) {
      const label = document.createElement('label');
      label.className = 'theme';
      label.innerHTML = `
        <input type="radio" name="theme" value="${id}" />
        <span class="preview" data-pdm="${id}">
          <i class="nav"></i><i class="tabs"></i><i class="r1"></i><i class="r2"></i><i class="r3"></i><i class="btn"></i>
        </span>
        <span class="name">${name}</span>`;
      box.append(label);
    }
  }
  box.querySelector(`input[value="${current}"]`).checked = true;
}

function renderColors(current) {
  const box = $('#colors');
  if (!box.querySelector('label')) {
    for (const { value, name, nameKey } of COLORS) {
      const localizedName = nameKey ? msg(nameKey) : name;
      const label = document.createElement('label');
      label.title = localizedName;
      label.innerHTML = `<input type="radio" name="color" value="${value}" aria-label="${localizedName}" /><span style="--c:${value}"></span>`;
      box.append(label);
    }
  }
  const match = box.querySelector(`input[value="${current}"]`);
  if (match) match.checked = true;
  else box.querySelectorAll('input').forEach((i) => (i.checked = false));
}

function renderPositions(current) {
  const box = $('#position');
  if (!box.querySelector('label')) {
    for (const { id, name, nameKey } of POSITIONS) {
      const localizedName = nameKey ? msg(nameKey) : name;
      const label = document.createElement('label');
      label.innerHTML = `<input type="radio" name="position" value="${id}" /><span>${localizedName}</span>`;
      box.append(label);
    }
  }
  box.querySelector(`input[value="${current}"]`).checked = true;
}

function renderSuggestions(savedServers, currentSite) {
  const box = $('#suggestions');
  box.replaceChildren();

  const currentName = (currentSite?.name || '').trim().toLowerCase();

  for (const s of savedServers) {
    const isCurrent = currentName && currentName === s.name.toLowerCase();
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `chip ${isCurrent ? 'active' : ''}`;
    btn.style.setProperty('--c', s.color);

    const dot = document.createElement('span');
    dot.className = 'chip-dot';

    const text = document.createElement('span');
    text.textContent = s.name;

    btn.append(dot, text);

    // Botón para borrar si no es uno de los presets nativos
    if (!s.isPreset) {
      const rm = document.createElement('span');
      rm.className = 'chip-remove';
      rm.innerHTML = '&times;';
      rm.title = msg('popupRemove') || 'Quitar';
      rm.addEventListener('click', async (e) => {
        e.stopPropagation();
        await deleteSavedServer(s.name);
        await render();
      });
      btn.append(rm);
    }

    // Al hacer clic en un servidor guardado, lo aplica al sitio actual sin perder nada
    btn.addEventListener('click', async () => {
      await updateSite(page.key, {
        name: s.name,
        color: s.color,
        critical: s.critical,
        tintBorder: s.tintBorder,
        position: s.position || currentSite.position,
      });

      await render();
    });

    box.append(btn);
  }
}

function renderSite(sites, savedServers) {
  const site = page ? matchSite(sites, page.url) : null;

  $('#unsupported').hidden = Boolean(page);
  $('#host').textContent = page ? page.key.replace(/^https?:\/\//, '') : msg('popupNoPage');

  const badge = $('#badge');
  badge.hidden = !page;
  if (page) {
    badge.textContent = page.isPma ? msg('popupPmaDetected') : msg('popupPmaNotDetected');
    badge.dataset.state = page.isPma ? 'ok' : 'warn';
  }

  const activateBtn = $('#activate');
  activateBtn.hidden = !page || Boolean(site);
  activateBtn.textContent = page?.isPma === false ? msg('popupActivateAnyway') : msg('popupActivate');

  $('#controls').hidden = !site;
  if (!site) return;

  $('#enabled').checked = site.enabled;
  const input = $('#serverName');
  if (document.activeElement !== input) input.value = site.name;
  paintPill($('#preview'), site);
  renderColors(site.color);
  renderPositions(site.position);
  renderSuggestions(savedServers, site);
  $('#titleTag').checked = site.title;
  $('#critical').checked = Boolean(site.critical);
  $('#tintBorder').checked = Boolean(site.tintBorder);
}

function renderSiteList(sites) {
  const keys = Object.keys(sites);
  $('#siteCount').textContent = keys.length;

  const list = $('#sites');
  list.replaceChildren();
  if (!keys.length) {
    const empty = document.createElement('li');
    empty.className = 'empty';
    empty.textContent = msg('popupNoServers');
    list.append(empty);
    return;
  }
  for (const key of keys) {
    const site = normalizeSite(sites[key]);
    const li = document.createElement('li');

    const who = document.createElement('span');
    who.className = 'who';
    if (site.name) {
      const pill = document.createElement('span');
      pill.className = 'pill';
      paintPill(pill, site);
      who.append(pill);
    }
    const code = document.createElement('code');
    code.textContent = key.replace(/^https?:\/\//, '');
    code.title = key;
    who.append(code);

    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = msg('popupRemove');
    button.addEventListener('click', () => removeSite(key));
    li.append(who, button);
    list.append(li);
  }
}

async function renderShortcut() {
  const commands = await chrome.commands.getAll();
  const shortcut = commands.find((c) => c.name === 'toggle-dark')?.shortcut;
  $('#shortcut').textContent = shortcut
    ? msg('popupShortcutActive', [shortcut])
    : msg('popupShortcutNone');
}

function applyI18n() {
  const setTxt = (id, key) => {
    const el = $(id);
    if (el) el.textContent = msg(key);
  };
  setTxt('#unsupported', 'popupUnsupported');
  setTxt('#darkModeLabel', 'popupDarkMode');
  setTxt('#serverNameLabel', 'popupServerName');
  setTxt('#savedServersLabel', 'popupSavedServers');
  setTxt('#btnAddServer', 'popupAddServer');
  setTxt('#posLabel', 'popupLabelPosition');
  setTxt('#titleTagLabel', 'popupShowInTitle');
  setTxt('#criticalLabel', 'popupCritical');
  setTxt('#tintBorderLabel', 'popupTintBorder');
  setTxt('#themesLegend', 'popupTheme');
  setTxt('#densityLabel', 'popupDensity');
  setTxt('#densityComfortable', 'popupDensityComfortable');
  setTxt('#densityCompact', 'popupDensityCompact');
  setTxt('#serversSummary', 'popupServersActivated');

  const nameInput = $('#serverName');
  if (nameInput) nameInput.placeholder = msg('popupServerNamePlaceholder');

  const optBtn = $('#openOptions');
  if (optBtn) optBtn.title = msg('popupOptions');
}

async function handleAddServer() {
  const input = $('#serverName');
  const name = (input.value || '').trim().slice(0, NAME_MAX);
  if (!name) {
    input.focus();
    return;
  }

  const color = $('#colors input:checked')?.value ?? PDM.DEFAULT_COLOR;
  const critical = $('#critical').checked;
  const tintBorder = $('#tintBorder').checked;
  const position = $('#position input:checked')?.value ?? PDM.DEFAULT_POSITION;

  await persistServer({ name, color, critical, tintBorder, position });
  await updateSite(page.key, { name, color, critical, tintBorder, position });

  const btn = $('#btnAddServer');
  if (btn) {
    btn.textContent = msg('popupServerSaved') || '✓ Guardado';
    btn.classList.add('saved');
    setTimeout(() => {
      btn.textContent = msg('popupAddServer') || '+ Agregar servidor';
      btn.classList.remove('saved');
    }, 1400);
  }

  await render();
}

async function render() {
  const { theme, density, sites, savedServers } = await storage.read();
  root.dataset.pdm = theme;
  renderThemes(theme);
  $(`#density input[value="${density}"]`).checked = true;
  renderSite(sites, savedServers);
  renderSiteList(sites);
}

/* ───────── Init ───────── */

$('#activate').addEventListener('click', activate);

$('#enabled').addEventListener('change', (e) => updateSite(page.key, { enabled: e.target.checked }));

// Al escribir, solo actualiza la vista previa y el sitio actual (NO crea servidores automáticamente)
const saveName = debounce(async (name) => {
  await updateSite(page.key, { name });
  const { sites, savedServers } = await storage.read();
  renderSuggestions(savedServers, sites[page.key]);
}, 150);

$('#serverName').addEventListener('input', (e) => {
  const name = e.target.value.trim().slice(0, NAME_MAX);
  const color = $('#colors input:checked')?.value ?? PDM.DEFAULT_COLOR;
  paintPill($('#preview'), { name, color });
  saveName(name);
});

$('#serverName').addEventListener('keydown', async (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    await handleAddServer();
    $('#serverName').blur();
  }
});

$('#btnAddServer').addEventListener('click', handleAddServer);

$('#colors').addEventListener('change', async (e) => {
  await updateSite(page.key, { color: e.target.value });
  await render();
});

$('#position').addEventListener('change', (e) => updateSite(page.key, { position: e.target.value }));
$('#titleTag').addEventListener('change', (e) => updateSite(page.key, { title: e.target.checked }));
$('#critical').addEventListener('change', (e) => updateSite(page.key, { critical: e.target.checked }));
$('#tintBorder').addEventListener('change', (e) => updateSite(page.key, { tintBorder: e.target.checked }));

$('#openOptions').addEventListener('click', () => {
  if (chrome.runtime.openOptionsPage) {
    chrome.runtime.openOptionsPage();
  } else {
    window.open(chrome.runtime.getURL('options/options.html'));
  }
});

$('#themes').addEventListener('change', async (e) => {
  await storage.write({ theme: e.target.value });
  root.dataset.pdm = e.target.value;
});

$('#density').addEventListener('change', (e) => storage.write({ density: e.target.value }));

(async () => {
  applyI18n();
  $('#version').textContent = `v${chrome.runtime.getManifest().version}`;
  page = await inspect();
  await pruneSites();
  if (page) {
    const { sites } = await storage.read();
    const match = matchSite(sites, page.url);
    if (match) page.key = match.key;
  }
  await render();
  await renderShortcut();
})();
