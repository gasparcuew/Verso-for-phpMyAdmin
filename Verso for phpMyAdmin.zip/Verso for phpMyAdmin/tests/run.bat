@echo off
node "%~dp0visual-scan.js"
