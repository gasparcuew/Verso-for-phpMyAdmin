#!/usr/bin/env bash
node "$(dirname "$0")/visual-scan.js"
