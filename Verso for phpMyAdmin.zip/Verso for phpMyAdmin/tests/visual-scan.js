

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
let errors = 0;
let warnings = 0;

function assert(condition, message) {
  if (!condition) {
    console.error(`❌ FAIL: ${message}`);
    errors++;
  } else {
    console.log(`✅ PASS: ${message}`);
  }
}

function warn(condition, message) {
  if (!condition) {
    console.warn(`⚠️ WARN: ${message}`);
    warnings++;
  }
}

console.log('=== Iniciando pruebas de Verso for phpMyAdmin v1.0 ===\n');

// 1. Manifest
console.log('--- 1. Verificación de manifest.json ---');
const manifestPath = path.join(ROOT, 'manifest.json');
assert(fs.existsSync(manifestPath), 'manifest.json existe');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

assert(manifest.manifest_version === 3, 'Manifest Version es 3');
assert(manifest.version === '1.0.0', 'Versión es 1.0.0');
assert(manifest.default_locale === 'en', 'default_locale está configurado');
assert(manifest.options_page === 'options/options.html', 'options_page registrado');

// Verificar archivos declarados en manifest
const filesToCheck = [
  manifest.action?.default_popup,
  manifest.options_page,
  manifest.background?.service_worker,
  ...Object.values(manifest.icons || {}),
].filter(Boolean);

for (const rel of filesToCheck) {
  assert(fs.existsSync(path.join(ROOT, rel)), `Archivo manifest existe: ${rel}`);
}

// 2. i18n
console.log('\n--- 2. Verificación de i18n (locales) ---');
const enPath = path.join(ROOT, '_locales', 'en', 'messages.json');
const esPath = path.join(ROOT, '_locales', 'es', 'messages.json');
assert(fs.existsSync(enPath), 'messages.json (en) existe');
assert(fs.existsSync(esPath), 'messages.json (es) existe');

const en = JSON.parse(fs.readFileSync(enPath, 'utf8'));
const es = JSON.parse(fs.readFileSync(esPath, 'utf8'));

const enKeys = Object.keys(en);
const esKeys = Object.keys(es);

assert(enKeys.length > 0, `Locales (en) tiene ${enKeys.length} mensajes`);
assert(esKeys.length > 0, `Locales (es) tiene ${esKeys.length} mensajes`);

const missingInEs = enKeys.filter(k => !es[k]);
const missingInEn = esKeys.filter(k => !en[k]);

assert(missingInEs.length === 0, `Todas las claves EN están en ES (faltan: ${missingInEs.join(', ') || 'ninguna'})`);
assert(missingInEn.length === 0, `Todas las claves ES están en EN (faltan: ${missingInEn.join(', ') || 'ninguna'})`);

// 3. Verificación de CSS y selectores críticos
console.log('\n--- 3. Verificación de selectores y tokens CSS ---');
const baseCss = fs.readFileSync(path.join(ROOT, 'css', 'base.css'), 'utf8');
const envCss = fs.readFileSync(path.join(ROOT, 'css', 'env.css'), 'utf8');
const tablesCss = fs.readFileSync(path.join(ROOT, 'css', 'tables-pro.css'), 'utf8');
const compatCss = fs.readFileSync(path.join(ROOT, 'css', 'compat.css'), 'utf8');

assert(baseCss.includes('dbsGroup') && baseCss.includes('navGroup'), 'css/base.css cubre grupos .dbsGroup y .navGroup');
assert(baseCss.includes('color: var(--pdm-text) !important'), 'css/base.css fuerza color legible en grupos con !important');
assert(baseCss.includes("content: 'grupo'"), 'css/base.css incluye indicador badge para bases de datos agrupadas');
assert(envCss.includes('data-pdm-tint'), 'css/env.css incluye soporte para tinte total data-pdm-tint');
assert(tablesCss.includes('position: sticky') || tablesCss.includes('sticky'), 'css/tables-pro.css incluye cabeceras sticky');
assert(compatCss.includes('data-pdm-pma'), 'css/compat.css incluye selectores para versiones 4.9, 5.1 y 6.0');

// 4. Content scripts
console.log('\n--- 4. Verificación de scripts content y lib ---');
const pdmJs = fs.readFileSync(path.join(ROOT, 'lib', 'pdm.js'), 'utf8');
const bootJs = fs.readFileSync(path.join(ROOT, 'content', 'boot.js'), 'utf8');
const guardJs = fs.readFileSync(path.join(ROOT, 'content', 'sql-guard.js'), 'utf8');
const tablesJs = fs.readFileSync(path.join(ROOT, 'content', 'tables-pro.js'), 'utf8');
const bgJs = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');

assert(pdmJs.includes('critical: site.critical === true'), 'lib/pdm.js normaliza flag critical');
assert(pdmJs.includes('tintBorder: site.tintBorder === true'), 'lib/pdm.js normaliza flag tintBorder');
assert(pdmJs.includes('normalizeSavedServers'), 'lib/pdm.js tiene normalización de savedServers');
assert(bootJs.includes('__pdmState'), 'content/boot.js expone __pdmState');
assert(guardJs.includes('detectDanger') && guardJs.includes('showConfirmModal'), 'content/sql-guard.js tiene detección y modal');
assert(tablesJs.includes('showToast'), 'content/tables-pro.js tiene utilidades y toast');
assert(bgJs.includes('content/sql-guard.js') && bgJs.includes('content/tables-pro.js'), 'background.js registra sql-guard y tables-pro');
assert(bgJs.includes("'savedServers'"), 'background.js sincroniza savedServers');

// Resumen
console.log('\n=============================================');
if (errors === 0) {
  console.log(`🎉 ¡TODOS LOS TESTS PASARON EXITOSAMENTE! (Errores: ${errors}, Avisos: ${warnings})`);
  process.exit(0);
} else {
  console.error(`💥 SE ENCONTRARON ${errors} ERROR(ES). Revisa los fallos arriba.`);
  process.exit(1);
}
