"""Genera css/icons.css: reemplaza los sprites PNG de phpMyAdmin por íconos SVG (máscaras CSS)."""
import urllib.parse, json, sys
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'css' / 'icons.css'

P = lambda d: f'<path d="{d}"/>'
ICONS = {
 'edit': P('M12 20h9')+P('M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z'),
 'copy': '<rect x="9" y="9" width="12" height="12" rx="2"/>'+P('M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1'),
 'plus': P('M12 5v14M5 12h14'),
 'minus': P('M5 12h14'),
 'trash': P('M3 6h18')+P('M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6')+P('M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2')+P('M10 11v6M14 11v6'),
 'eraser': P('m7 21-4.3-4.3a1 1 0 0 1 0-1.4l9-9a1 1 0 0 1 1.4 0l5.6 5.6a1 1 0 0 1 0 1.4L13 21')+P('M22 21H7')+P('m5 11 9 9'),
 'rows': '<rect x="3" y="3" width="18" height="18" rx="2"/>'+P('M3 9h18M3 15h18'),
 'table': '<rect x="3" y="3" width="18" height="18" rx="2"/>'+P('M3 9h18M3 15h18M9 3v18'),
 'list': P('M8 6h13M8 12h13M8 18h13')+P('M3 6h.01M3 12h.01M3 18h.01'),
 'terminal': P('m4 17 6-6-6-6')+P('M12 19h8'),
 'search': '<circle cx="11" cy="11" r="7"/>'+P('m21 21-4.3-4.3'),
 'upload': P('M12 15V3')+P('m7 8 5-5 5 5')+P('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'),
 'download': P('M12 3v12')+P('m7 10 5 5 5-5')+P('M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4'),
 'wrench': P('M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76Z'),
 'history': P('M3 12a9 9 0 1 0 3-6.7L3 8')+P('M3 3v5h5')+P('M12 7v5l3 2'),
 'zap': P('M13 2 3 14h9l-1 8 10-12h-9Z'),
 'braces': P('M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5a2 2 0 0 0 2 2h1')+P('M16 21h1a2 2 0 0 0 2-2v-5a2 2 0 0 1 2-2 2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1'),
 'calendar': '<rect x="3" y="4" width="18" height="18" rx="2"/>'+P('M16 2v4M8 2v4M3 10h18'),
 'network': '<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/>'+P('M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3M12 12V8'),
 'key': '<circle cx="7.5" cy="15.5" r="5.5"/>'+P('m21 2-9.6 9.6')+P('m15.5 7.5 3 3L22 7l-3-3'),
 'users': P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2')+'<circle cx="9" cy="7" r="4"/>'+P('M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75'),
 'user': P('M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2')+'<circle cx="12" cy="7" r="4"/>',
 'user-plus': P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2')+'<circle cx="9" cy="7" r="4"/>'+P('M19 8v6M22 11h-6'),
 'user-x': P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2')+'<circle cx="9" cy="7" r="4"/>'+P('m17 8 5 5M22 8l-5 5'),
 'user-check': P('M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2')+'<circle cx="9" cy="7" r="4"/>'+P('m16 11 2 2 4-4'),
 'home': P('m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z')+P('M9 22V12h6v10'),
 'logout': P('M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4')+P('m16 17 5-5-5-5M21 12H9'),
 'settings': '<circle cx="12" cy="12" r="3"/>'+P('M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h.01a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.01a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v.01a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z'),
 'sliders': P('M21 4h-7M10 4H3M21 12h-9M8 12H3M21 20h-5M12 20H3M14 2v4M8 10v4M16 18v4'),
 'book': P('M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20'),
 'help': '<circle cx="12" cy="12" r="10"/>'+P('M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01'),
 'refresh': P('M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8')+P('M21 3v5h-5')+P('M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16')+P('M8 16H3v5'),
 'minus-square': '<rect x="3" y="3" width="18" height="18" rx="2"/>'+P('M8 12h8'),
 'more': '<circle cx="12" cy="12" r="1.2" fill="black"/><circle cx="19" cy="12" r="1.2" fill="black"/><circle cx="5" cy="12" r="1.2" fill="black"/>',
 'database': '<ellipse cx="12" cy="5" rx="9" ry="3"/>'+P('M3 5v14a9 3 0 0 0 18 0V5')+P('M3 12a9 3 0 0 0 18 0'),
 'eye': P('M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z')+'<circle cx="12" cy="12" r="3"/>',
 'eye-off': P('M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10 8 10 8a13.16 13.16 0 0 1-1.67 2.68')+P('M6.61 6.61A13.53 13.53 0 0 0 2 12s3 8 10 8a9.74 9.74 0 0 0 5.39-1.61')+P('m2 2 20 20'),
 'bookmark': P('m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2Z'),
 'star': P('m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01Z'),
 'star-fill': '<path fill="black" d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01Z"/>',
 'chart': P('M12 20V10M18 20V4M6 20v-4'),
 'activity': P('M22 12h-4l-3 9L9 3l-3 9H2'),
 'server': '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/>'+P('M6 6h.01M6 18h.01'),
 'globe': '<circle cx="12" cy="12" r="10"/>'+P('M2 12h20')+P('M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z'),
 'check-circle': '<circle cx="12" cy="12" r="10"/>'+P('m9 12 2 2 4-4'),
 'x-circle': '<circle cx="12" cy="12" r="10"/>'+P('m15 9-6 6M9 9l6 6'),
 'alert': P('m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z')+P('M12 9v4M12 17h.01'),
 'info': '<circle cx="12" cy="12" r="10"/>'+P('M12 16v-4M12 8h.01'),
 'bulb': P('M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5')+P('M9 18h6M10 22h4'),
 'bulb-off': P('M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5')+P('M9 18h6M10 22h4')+P('m2 2 20 20'),
 'lines': P('M3 6h18M3 12h12M3 18h6'),
 'diamond': P('m12 3 9 9-9 9-9-9Z'),
 'save': P('M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z')+P('M17 21v-8H7v8M7 3v5h8'),
 'printer': P('M6 9V2h12v7')+P('M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2')+P('M6 14h12v8H6Z'),
 'file': P('M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z')+P('M14 2v6h6M16 13H8M16 17H8M10 9H8'),
 'undo': P('M3 7v6h6')+P('M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13'),
 'move': P('m5 9-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20'),
 'chevrons-left': P('m11 17-5-5 5-5M18 17l-5-5 5-5'),
 'chevron-left': P('m15 18-6-6 6-6'),
 'chevron-right': P('m9 18 6-6-6-6'),
 'chevrons-right': P('m13 17 5-5-5-5M6 17l5-5-5-5'),
 'arrow-up': P('m5 12 7-7 7 7M12 19V5'),
 'arrow-down': P('M12 5v14M19 12l-7 7-7-7'),
 'arrow-left': P('m12 19-7-7 7-7M19 12H5'),
 'arrow-right': P('M5 12h14M12 5l7 7-7 7'),
 'sort': P('m7 15 5 5 5-5M7 9l5-5 5 5'),
 'lock': '<rect x="3" y="11" width="18" height="11" rx="2"/>'+P('M7 11V7a5 5 0 0 1 10 0v4'),
 'unlock': '<rect x="3" y="11" width="18" height="11" rx="2"/>'+P('M7 11V7a5 5 0 0 1 9.9-1'),
 'cpu': '<rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/>'+P('M15 2v2M15 20v2M2 15h2M2 9h2M20 15h2M20 9h2M9 2v2M9 20v2'),
 'message': P('M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2Z'),
 'text': P('M17 6.1H3M21 12.1H3M15.1 18H3'),
 'pin': P('M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z')+'<circle cx="12" cy="10" r="3"/>',
 'package': P('m7.5 4.27 9 5.15M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z')+P('m3.3 7 8.7 5 8.7-5M12 22V12'),
 'link': P('M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71')+P('M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71'),
 'unlink': P('M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71')+P('M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71')+P('m2 2 20 20'),
 'play': P('m6 3 14 9-14 9Z'),
 'pause': P('M6 4h4v16H6zM14 4h4v16h-4z'),
 'x': P('M18 6 6 18M6 6l12 12'),
 'shield': P('M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z'),
 'layers': P('m12 2 10 5-10 5L2 7Z')+P('m2 17 10 5 10-5M2 12l10 5 10-5'),
 'copy-plus': '<rect x="9" y="9" width="12" height="12" rx="2"/>'+P('M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1')+P('M15 13v4M13 15h4'),
}

# icono -> clases ic_* de phpMyAdmin (sin el prefijo "ic_")
MAP = {
 'edit': 'b_edit b_inline_edit bd_edit b_usredit b_rename',
 'copy': '',  # solo en acciones de fila (ver CONTEXT)
 'plus': 'b_insrow bd_insrow b_plus b_table_add b_newtbl b_snewtbl b_newdb b_column_add b_index_add b_view_add b_routine_add bd_routine_add b_event_add b_trigger_add b_usradd new_data',
 'minus': 'b_minus',
 'trash': 'b_drop bd_drop b_deltbl bd_deltbl db_drop col_drop b_usrdrop',
 'eraser': 'b_empty bd_empty',
 'rows': 'b_browse bd_browse b_sbrowse bd_sbrowse',
 'table': 's_tbl',
 'list': 'b_props new_struct',
 'terminal': 'b_sql console',
 'search': 'b_search b_find_replace b_select bd_select',
 'upload': 'b_export bd_export b_tblexport',
 'download': 'b_import b_tblimport',
 'wrench': 'b_tblops',
 'history': 'b_versions',
 'zap': 'b_triggers b_tbloptimize',
 'braces': 'b_routines',
 'calendar': 'b_events b_calendar',
 'network': 'b_relations',
 'key': 'b_primary bd_primary s_passwd',
 'users': 'b_usrlist b_group',
 'user-check': 'b_usrcheck',
 'home': 'b_home',
 'logout': 's_loggoff',
 'settings': 's_cog',
 'sliders': 's_vars s_theme',
 'book': 'b_docs b_docsql b_sqlhelp b_sqldoc',
 'help': 'b_help s_really',
 'refresh': 's_reload s_sync',
 'minus-square': 's_collapseall',
 'more': 'b_more more',
 'database': 's_db b_sdb b_dbstatistics',
 'eye': 'b_view eye eye_grey show',
 'eye-off': 'hide',
 'layers': 's_views b_views',
 'bookmark': 'b_bookmark',
 'star': 'b_no_favorite',
 'star-fill': 'b_favorite',
 'chart': 'b_chart b_tblanalyse',
 'activity': 's_status s_process',
 'server': 's_host',
 'globe': 'b_globe s_lang',
 'check-circle': 's_okay s_success',
 'x-circle': 's_error s_cancel s_cancel2',
 'alert': 's_attention s_notice',
 'info': 's_info',
 'bulb': 'b_tipp lightbulb',
 'bulb-off': 'lightbulb_off',
 'lines': 'b_index bd_index',
 'diamond': 'b_unique bd_unique',
 'save': 'b_save b_saveimage',
 'printer': 'b_print',
 'file': 'b_pdfdoc b_report',
 'undo': 'b_undo',
 'move': 'b_move',
 'chevrons-left': 'b_firstpage bd_firstpage',
 'chevron-left': 'b_prevpage bd_prevpage',
 'chevron-right': 'b_nextpage bd_nextpage',
 'chevrons-right': 'b_lastpage bd_lastpage',
 'arrow-left': 'b_left',
 'arrow-right': 'b_right',
 'arrow-up': 's_asc s_asci s_top asc_order',
 'arrow-down': 's_desc',
 'sort': 's_sortable',
 'lock': 's_lock',
 'unlock': 's_unlock',
 'cpu': 'b_engine',
 'message': 'b_comment',
 'text': 'b_ftext bd_ftext s_fulltext s_partialtext',
 'pin': 'b_spatial bd_spatial',
 'package': 'b_plugin',
 'link': 's_link',
 'unlink': 's_unlink',
 'play': 'play',
 'pause': 'pause',
 'x': 'b_close',
 'shield': 's_rights',
}

# Casos que dependen del contexto (misma clase de phpMyAdmin, significado distinto)
CONTEXT = [
 ('copy-plus', ['.table_results .icon.ic_b_insrow', '.table_results .icon.ic_bd_insrow']),
]

def uri(inner):
    svg = ("<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='black' "
           "stroke-width='1.75' stroke-linecap='round' stroke-linejoin='round'>" + inner.replace('"', "'") + "</svg>")
    return 'url("data:image/svg+xml,' + urllib.parse.quote(svg, safe="/:=' ,.()-") + '")'

ROOT = 'html:root[data-pdm]'
used = []
blocks = []
for key, classes in MAP.items():
    cl = classes.split()
    if not cl: continue
    assert key in ICONS, key
    sel = ', '.join(f'.icon.ic_{c}' for c in cl)
    used += cl
    blocks.append((sel, key))
for key, sels in CONTEXT:
    blocks.append((', '.join(sels), key))

all_sel = ', '.join(f'.icon.ic_{c}' for c in used)
css = []
css.append("""/*
 * Íconos modernos. GENERADO por tools/build_icons.py — no editar a mano.
 * Sustituye los sprites PNG de phpMyAdmin por SVG de trazo redondeado usados como
 * máscara: heredan `color`, así que funcionan con cualquier theme y estado
 * (hover, activo, deshabilitado).
 */
""")
css.append(f"""{ROOT} {{
  & :is({all_sel}) {{
    background: currentColor;
    -webkit-mask-repeat: no-repeat;
    mask-repeat: no-repeat;
    -webkit-mask-position: center;
    mask-position: center;
    -webkit-mask-size: 16px 16px;
    mask-size: 16px 16px;
    width: 16px;
    height: 16px;
    vertical-align: -0.2em;
    opacity: 0.92;
  }}
  /* variantes deshabilitadas (bd_*) */
  & :is(.icon[class*=' ic_bd_'], .icon[class^='ic_bd_']) {{
    opacity: 0.35;
  }}""")
for sel, key in blocks:
    u = uri(ICONS[key])
    css.append(f"  & :is({sel}) {{\n    -webkit-mask-image: {u};\n    mask-image: {u};\n  }}")
css.append("}\n")
OUT.write_text('\n'.join(css))
print('clases mapeadas:', len(used), ' iconos usados:', len(blocks))
